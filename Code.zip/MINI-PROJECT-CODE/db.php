$con = mysqli_connect("sql109.epizy.com","epiz_27262790","XxyEv5l0FHbKHIh");
    if (mysqli_connect_errno()){
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }